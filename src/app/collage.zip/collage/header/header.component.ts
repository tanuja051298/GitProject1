import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent {

  public isShow:boolean= true;

  constructor(private route: Router){

  }
  
  onClickOfAdmsn(){
    console.log("Hello this is comp.ts");
    if(this.isShow==true){
      // this.route.navigate({'admsn']);

      this.route.navigateByUrl('admsn');
    }
  }

}
