import { Component } from '@angular/core';

@Component({
  selector: 'app-admsn',
  templateUrl: './admsn.component.html',
  styleUrls: ['./admsn.component.css']
})
export class AdmsnComponent {

}
